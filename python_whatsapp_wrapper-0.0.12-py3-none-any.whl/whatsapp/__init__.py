"""
Pure python project for META Whatsapp Business API wrapper.
"""

from . import _version

__version__ = _version.__version__
