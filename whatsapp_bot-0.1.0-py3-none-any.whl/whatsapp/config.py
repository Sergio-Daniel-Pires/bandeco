import os

WHATSAPP_TOKEN = os.environ.get("WHATSAPP_TOKEN")
"""
Whatsapp Business META API token
"""
 
VERIFY_TOKEN = os.environ.get("VERIFY_TOKEN")
"""
Verify Token defined when configuring webhook
"""

PHONE_NUMBER_ID = os.environ.get("PHONE_NUMBER_ID")
"""
Meta configured phone number ID
"""