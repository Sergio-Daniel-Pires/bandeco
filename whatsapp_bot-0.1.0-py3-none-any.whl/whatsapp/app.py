from typing import Any

import flask

from whatsapp.bot import WhatsappBot
from whatsapp.utils import middleware


def create_app (bot: WhatsappBot, config: dict[str, Any] = None) -> flask.Flask:
    app = flask.Flask(__name__)

    @app.route("/", methods=[ "POST", "GET" ])
    @middleware
    def webhook ():
        return bot._handle_message(flask.request)

    @app.route("/healthcheck", methods=[ "GET" ])
    def healthcheck ():
        return "Everthing all right!"
    
    return app

if __name__ == "__main__":
    app = create_app()
    app.run(debug=True, use_reloader=True)
